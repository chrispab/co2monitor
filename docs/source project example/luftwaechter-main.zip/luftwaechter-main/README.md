# luftwaechter
CO2-Temperatur-Feuchtigkeits-Sensor mit ESP32 und MH-Z19B, DHT22 und WLAN-Funktionalität

libraries.zip herunterladen und entpacken in ~/Arduino/libraries

